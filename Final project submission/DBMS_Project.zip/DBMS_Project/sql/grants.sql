use project;


CREATE ROLE 'admin', 'customer';

GRANT ALL ON project.* TO 'admin';
Grant select on product to 'customer';


CREATE USER 'admin1'@'localhost' IDENTIFIED BY 'admin1';
CREATE USER 'customer1'@'localhost' IDENTIFIED BY 'customer1';

GRANT 'admin' TO 'admin1'@'localhost';
GRANT 'customer' TO 'customer1'@'localhost';

