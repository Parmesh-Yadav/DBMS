
CREATE INDEX Product_index
ON Product (pid, rating, price, offer); 

 
CREATE INDEX Account_index
ON Account (aid); 

 
CREATE INDEX Order_index
ON Orders (Mode_of_Payment); 

 
CREATE INDEX Supplies_index
ON Supplies (sid); 

 
CREATE INDEX Warehouse_index
ON Warehouse (pincode); 

CREATE INDEX customer_index
ON Customers (cid, pincode); 


CREATE INDEX storedIn_index
ON Storedin (pid); 

CREATE INDEX Employee_index
ON Employee (salary); 
