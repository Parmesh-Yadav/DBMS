use project;

Create view v1 as Select eid, cid from address where status = 0;

Create view v2 as Select avg(reviews.star), pid from reviews group by pid;

select * from v1;
select * from v2;