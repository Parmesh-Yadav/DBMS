use project;

Create trigger check_stock after insert on orders
For each row
Update Product set stock = stock-1 where pid=p1;


Create trigger removeAcc 
After delete 
on Account
For each Row
Delete from CUSTOMERS where cid = old.cid;


create trigger updateStock 
after INSERT 
on Returns
For each Row
Update Product set stock = stock + 1 where pid = new.pid;

Create trigger updateSalary
After update
On employee
For each row
Update employee set salary = salary + 10000 where eid = old.eid and old.designation = ‘SERVICE’ and new.designation = ‘MANAGER’;




